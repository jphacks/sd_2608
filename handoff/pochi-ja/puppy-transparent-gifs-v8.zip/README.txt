小狗透明 GIF · 当前 7 组动作

每个 GIF 为 512×512，透明背景，循环播放，保持原始每帧时长。
直接由当前有效的 107 张透明 PNG 编码，未经过浅色背景 GIF。
GIF 透明度只有透明/不透明两档，边缘半透明像素以 alpha 128 为阈值处理。
全部 GIF 重复播放便于查看；实际应用循环配置见 manifest.json 的 application_loop。
解压后双击 index.html 可切换棋盘格、白色或深色背景检查透明效果。
idle=待机，reminder=休息提醒，rest=休息中，record=记录工作，
welcome=欢迎回来，turn_sit=转身再坐下，rest_to_sit=趴卧起身坐好（第三版）。
